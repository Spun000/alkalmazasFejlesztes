package futoverseny.futoverseny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutoversenyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutoversenyApplication.class, args);
	}

}
